<?php
/***********************************************************************************
 * The contents of this file are subject to the Extension License Agreement
 * ("Agreement") which can be viewed at
 * https://www.espocrm.com/extension-license-agreement/.
 * By copying, installing downloading, or using this file, You have unconditionally
 * agreed to the terms and conditions of the Agreement, and You may not use this
 * file except in compliance with the Agreement. Under the terms of the Agreement,
 * You shall not license, sublicense, sell, resell, rent, lease, lend, distribute,
 * redistribute, market, publish, commercialize, or otherwise transfer rights or
 * usage to the software or any modified version or derivative work of the software
 * created by or for you.
 *
 * Copyright (C) 2015-2025 Letrium Ltd.
 *
 * License ID: 7aa29beaed0091a4ebc6daf5f36dfad2
 ************************************************************************************/

namespace Espo\Modules\Advanced\Core\Workflow\Formula\Functions\BpmGroup\ProcessEntityGroup;

use Espo\Core\Exceptions\Error;
use Espo\ORM\Entity;

/**
 * @todo Rewrite to inherit from BaseFunction.
 */
class AttributeType extends \Espo\Core\Formula\Functions\EntityGroup\AttributeType
{
    /**
     * @return Entity
     * @throws Error
     */
    protected function getEntity()
    {
        $variables = $this->getVariables();

        if (!isset($variables->__processEntity)) {
            throw new Error("Formula processEntity\\attribute can't be used out of process");
        }

        return $variables->__processEntity;
    }
}
