<div class="clearfix">
    <a
        role="button"
        tabindex="0"
        class="pull-right"
        data-action="removeGroup"
    ><span class="fas fa-times"></span></a>
</div>
<div class="row form-group">
    <div class="col-md-12 function-container field" data-name="function">{{{function}}}</div>
    <div class="col-md-12 attribute-container field" data-name="attribute">{{{attribute}}}</div>
    <div class="col-md-12 expression-container field" data-name="expression">{{{expression}}}</div>
    <div class="col-md-12 operator-container field" data-name="operator" style="margin-top: var(--2px);">{{{operator}}}</div>
    <div class="col-md-12 value-container field" data-name="value">{{{value}}}</div>
</div>
